package com.example.pokerai

object Config {
    // (kept only so older build files keep working; this mini app does not use AI)
    const val KEY = ""
    const val BASE_URL = ""
    const val MODEL = ""

    // Firebase Realtime Database (Data tab -> the URL shown on top)
    const val DB_URL = "https://szzdudjd-default-rtdb.firebaseio.com"
    // Name of this phone inside the database: bots/<BOT_ID>. Empty = random id made on first run.
    const val BOT_ID = ""
}
