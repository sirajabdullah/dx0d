package com.example.pokerai

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.ViewOutlineProvider
import android.widget.Button
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        col.addView(TextView(this).apply { text = "Poker AI"; textSize = 24f; setTypeface(typeface, Typeface.BOLD) })
        col.addView(TextView(this).apply {
            text = "1) Turn on Poker AI in Accessibility.\n2) The menu opens by itself: Start, Small / Normal / Big.\n3) It is online: every 10 seconds it follows your choice in Firebase."
            textSize = 15f; setPadding(0, (12 * d).toInt(), 0, (12 * d).toInt())
        })
        col.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "Allow microphone (voice commands)"
            setOnClickListener { requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 1) }
        })
        setContentView(col)
    }
}

class PokerService : AccessibilityService() {
    private var shell: Shell? = null
    override fun onServiceConnected() { shell = Shell(this).also { it.showBubble(); it.openMenu(); it.startOnline() } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { shell?.destroy(); shell = null; return super.onUnbind(i) }
}

class Shell(private val svc: PokerService) {
    private val h = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private val prefs get() = svc.getSharedPreferences("p", Context.MODE_PRIVATE)
    private val wm get() = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dens get() = svc.resources.displayMetrics.density
    private fun dp(i: Int) = (i * dens).toInt()

    private var bubble: ImageView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var menu: LinearLayout? = null
    private var statusTv: TextView? = null
    private var running = prefs.getBoolean("running", false)
    private var paused = prefs.getBoolean("paused", false)
    private var alive = true
    private var err = ""

    companion object { const val GAME = "com.boyaa.androidmarketar" }

    // ---------------------------------------------------------------- size
    private fun ui() = prefs.getInt("ui", 100)
    private fun sizeName(): String { val u = ui(); return if (u <= 85) "small" else if (u >= 130) "big" else "normal" }
    private fun setSize(name: String) {
        val v = when (name) { "small" -> 70; "big" -> 150; else -> 100 }
        prefs.edit().putInt("ui", v).apply()
        rebuildMenu()
        if (Config.DB_URL.isNotEmpty()) net.execute {
            try { dbReq("PUT", "/cmd/size.json", "\"" + name + "\""); dbReq("PUT", "/status.json", statusJson()); err = "" }
            catch (e: Exception) { err = e.message ?: "error" }
            showErr()
        }
    }

    // ---------------------------------------------------------------- every 27 s: say كبير / صغير, 3 times, as YOU chose
    private var badgeTv: TextView? = null
    private fun badge(text: String, color: Int, ms: Long) {
        h.post {
            try {
                badgeTv?.let { try { wm.removeView(it) } catch (e: Exception) {} }
                val tv = TextView(svc).apply {
                    this.text = text; textSize = 27f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setShadowLayer(6f, 0f, 0f, Color.BLACK)
                    setPadding(dp(22), dp(8), dp(22), dp(8))
                    val cols = if (color == 1) intArrayOf(0xFF065F46.toInt(), 0xFF10B981.toInt(), 0xFFFFD60A.toInt())
                               else intArrayOf(0xFF7F1D1D.toInt(), 0xFFE11D48.toInt(), 0xFFFF8A00.toInt())
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, cols).apply {
                        cornerRadius = dp(30).toFloat(); setStroke(dp(3), 0xFFFFFFFF.toInt())
                    }
                    elevation = dp(12).toFloat()
                    alpha = 0f; scaleX = 0.3f; scaleY = 0.3f
                }
                val lp = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(30) }
                wm.addView(tv, lp); badgeTv = tv
                tv.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2.2f)).start()
                h.postDelayed({
                    tv.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).translationY(-dp(20).toFloat()).setDuration(350).start()
                }, ms - 400)
                h.postDelayed({ try { wm.removeView(tv) } catch (e: Exception) {}; if (badgeTv === tv) badgeTv = null }, ms)
            } catch (e: Exception) {}
        }
    }

    private fun ar(w: String) = if (w == "big") "\u0643\u0628\u064A\u0631" else "\u0635\u063A\u064A\u0631"   // كبير / صغير
    private fun norm(x: String): String? {
        val t = x.trim().lowercase()
        return when {
            t.contains("big") || t.contains("\u0643\u0628") || t == "k" -> "big"
            t.contains("small") || t.contains("\u0635\u063A") || t == "s" -> "small"
            else -> null
        }
    }
    // Every 20 s the app decides BY ITSELF: كبير or صغير (no clicking). The word stays 3 s on screen
    // and is written online (Firebase). "Auto" can be turned off to choose the word by hand.
    private val ch = Handler(Looper.getMainLooper())
    private val rnd = java.security.SecureRandom()
    private fun auto() = prefs.getBoolean("auto", true)
    private fun word() = if (prefs.getString("word", "big") == "small") "small" else "big"
    private fun cycle() {
        if (!alive || paused) return
        val w = if (auto()) pickByMood() else word()
        prefs.edit().putString("word", w).apply()
        badge(ar(w), if (w == "big") 1 else 2, 3000)
        rebuildMenu()
        pushWord()
        ch.postDelayed({ cycle() }, 27000)
    }
    // Not a 50/50 coin: the app has a "mood" that drifts slowly. Sometimes it likes كبير for a while,
    // sometimes صغير, sometimes it suddenly changes its mind. The mood is saved and also written online.
    private fun mood(): Float = prefs.getFloat("mood", 0.3f + 0.4f * rnd.nextFloat())
    // History typed by the user: 'B' = big came out, 'S' = small came out (last 20 kept).
    private fun hist(): String = prefs.getString("hist", "") ?: ""
    private fun addResult(w: String) {
        val c = if (w == "big") 'B' else 'S'
        prefs.edit().putString("hist", (hist() + c).takeLast(20)).apply()
        restartCycle()
    }
    // how many results in a row are the same as the last one (e.g. big,big,big -> 3)
    private fun streak(): Pair<String, Int>? {
        val h = hist(); if (h.isEmpty()) return null
        val last = h.last(); var n = 0
        for (i in h.indices.reversed()) { if (h[i] == last) n++ else break }
        return (if (last == 'B') "big" else "small") to n
    }
    private fun clearHist() { prefs.edit().putString("hist", "").apply(); restartCycle() }
    private fun histView(): String = hist().takeLast(10).map { if (it == 'B') "\u2B06" else "\u2B07" }.joinToString(" ")
    // With >= 3 results: follow the majority of the last 5 (tie -> follow the last one).
    // This is a simple counting rule. It is NOT a real prediction: each round is independent.
    private fun pickByHistory(): String? {
        val h = hist().takeLast(5)
        if (h.length < 3) return null
        val b = h.count { it == 'B' }; val sm = h.length - b
        return when { b > sm -> "big"; sm > b -> "small"; else -> if (h.last() == 'B') "big" else "small" }
    }
    private fun pickByMood(): String {
        pickByHistory()?.let { return it }
        var m = mood()
        m += (rnd.nextGaussian().toFloat()) * 0.22f            // slow drift
        if (rnd.nextInt(10) == 0) m = rnd.nextFloat()          // now and then it changes its mind completely
        m = m.coerceIn(0.05f, 0.95f)
        prefs.edit().putFloat("mood", m).apply()
        return if (rnd.nextFloat() < m) "big" else "small"
    }
    private fun restartCycle() { ch.removeCallbacksAndMessages(null); if (!paused) cycle() }
    // Big red button: stops everything (cycle, word on screen, game running flag). State is saved, so it stays stopped.
    private fun pauseAll() {
        paused = true; running = false
        prefs.edit().putBoolean("paused", true).putBoolean("running", false).apply()
        ch.removeCallbacksAndMessages(null)
        badgeTv?.let { try { wm.removeView(it) } catch (e: Exception) {} }; badgeTv = null
        paint(); rebuildMenu(); pushNow()
    }
    private fun resumeAll() {
        paused = false
        prefs.edit().putBoolean("paused", false).apply()
        paint(); restartCycle(); rebuildMenu(); pushNow()
    }
    private fun pushWord() {
        if (Config.DB_URL.isEmpty()) return
        val w = word(); val m = if (auto()) "auto" else "manual"
        net.execute {
            try {
                dbReq("PUT", "/cmd/word.json", "\"" + w + "\"")
                dbReq("PUT", "/cmd/mode.json", "\"" + m + "\"")
                dbReq("PUT", "/status.json", statusJson()); err = ""
            } catch (e: Exception) { err = e.message ?: "error" }
            showErr()
        }
    }
    private fun setAuto(on: Boolean) { prefs.edit().putBoolean("auto", on).apply(); restartCycle() }
    private fun setWord(w: String) {
        prefs.edit().putBoolean("auto", false).putString("word", w).apply()
        restartCycle()
    }

    // ---------------------------------------------------------------- voice commands
    private var sr: SpeechRecognizer? = null
    private fun say(t: String) { h.post { Toast.makeText(svc, t, Toast.LENGTH_SHORT).show() } }
    fun listen() {
        h.post {
            if (svc.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                say("Allow microphone in the app first")
                svc.startActivity(Intent(svc, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return@post
            }
            if (!SpeechRecognizer.isRecognitionAvailable(svc)) { say("No speech service on this phone"); return@post }
            try { sr?.destroy() } catch (e: Exception) {}
            val r = SpeechRecognizer.createSpeechRecognizer(svc); sr = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    say("\uD83C\uDFA4 " + t); handleVoice(t)
                }
                override fun onError(e: Int) { say("\uD83C\uDFA4 ?") }
                override fun onReadyForSpeech(p: Bundle?) { say("\uD83C\uDFA4 ...") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
        }
    }
    // words are matched loosely (Arabic / English / Kurdish)
    private fun handleVoice(raw: String) {
        val t = raw.lowercase().trim()
        fun has(vararg k: String) = k.any { t.contains(it) }
        when {
            has("home", "\u0647\u0648\u0645", "\u0647\u06C6\u0645", "\u0627\u0644\u0631\u0626\u064A\u0633", "\u0631\u0626\u064A\u0633") ->
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            has("back", "\u0631\u062C\u0648\u0639", "\u0628\u0627\u0643", "\u062E\u0644\u0641") ->
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            has("game", "\u0642\u064A\u0645", "\u063A\u064A\u0645", "\u062C\u064A\u0645", "\u0644\u0639\u0628", "\u06AF\u06D5\u06CC\u0645", "\u06CC\u0627\u0631\u06CC") ->
                svc.packageManager.getLaunchIntentForPackage(GAME)?.let { svc.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            has("stop", "\u0648\u0642\u0641", "\u062A\u0648\u0642\u0641", "\u0627\u064A\u0642\u0627\u0641", "\u0631\u0627\u0648\u06CC\u0633\u062A", "\u0631\u0627\u0648\u06D5\u0633\u062A") -> pauseAll()
            has("resume", "\u0627\u0633\u062A\u0645\u0631", "\u0643\u0645\u0644", "\u0628\u06D5\u0631\u062F\u06D5\u0648\u0627\u0645") -> resumeAll()
            has("start", "\u0633\u062A\u0627\u0631\u062A", "\u0627\u0628\u062F\u0623", "\u062F\u06D5\u0633\u062A\u067E\u06CE") -> start()
            has("clear", "\u0645\u0633\u062D", "\u067E\u0627\u06A9") -> clearHist()
            has("\u0643\u0628\u064A\u0631", "\u0643\u0628\u06CC\u0631", "big") -> addResult("big")
            has("\u0635\u063A\u064A\u0631", "\u0635\u063A\u06CC\u0631", "small") -> addResult("small")
            else -> say("?")
        }
    }

    // ---------------------------------------------------------------- bubble
    fun showBubble() {
        val size = dp(64)
        val tv = ImageView(svc).apply {
            setImageResource(R.drawable.krd_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setPadding(dp(3), dp(3), dp(3), dp(3))
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        bubble = tv; paint()
        val lp = WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(120) }
        bubbleLp = lp
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx; lp.y = oy + dy; try { wm.updateViewLayout(tv, lp) } catch (x: Exception) {} }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu() else if (menu != null) rebuildMenu(); true }
                else -> false
            }
        }
        wm.addView(tv, lp)
    }

    private fun paint() {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.WHITE)
            setStroke(dp(3), if (running) 0xFF1B8E3E.toInt() else 0xFFFFB800.toInt())
        }
    }

    // ---------------------------------------------------------------- menu
    fun openMenu() { if (menu == null) showMenu() }
    private fun toggleMenu() { if (menu != null) hideMenu() else showMenu() }
    private fun hideMenu() {
        menu?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        menu = null; statusTv = null
    }
    private fun rebuildMenu() { if (menu != null) { hideMenu(); showMenu() } }

    private fun lineText(): String =
        if (err.isEmpty()) "\uD83C\uDF10 online \u2713  ID: " + botId() else "\u26A0 offline: " + err

    private fun showMenu() {
        val sc = ui() / 100f
        fun chip(t: String, color: Int, onClick: () -> Unit) = TextView(svc).apply {
            text = t; textSize = 14f * sc; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp((14 * sc).toInt()), dp((9 * sc).toInt()), dp((14 * sc).toInt()), dp((9 * sc).toInt()))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }
            setOnClickListener { onClick() }
        }
        fun lp(top: Int = 8) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
        val box = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dp((220 * sc).toInt())
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xF00B1237.toInt(), 0xF02A1670.toInt(), 0xF0140B3A.toInt())).apply {
                cornerRadius = dp(22).toFloat(); setStroke(dp(2), 0xCCFFB800.toInt())
            }
        }
        val head = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(svc).apply {
            setImageResource(R.drawable.krd_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(2), 0xFFFFB800.toInt()) }
            setPadding(dp(2), dp(2), dp(2), dp(2)); outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
        }, LinearLayout.LayoutParams(dp((44 * sc).toInt()), dp((44 * sc).toInt())))
        head.addView(TextView(svc).apply {
            text = "KRD  Poker AI"; textSize = 17f * sc; setTextColor(0xFFFFE600.toInt()); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), 0, 0, 0)
        })
        box.addView(head, lp(0))
        val st = TextView(svc).apply {
            text = lineText(); textSize = 11f * sc
            setTextColor(if (err.isEmpty()) 0xFF93C5FD.toInt() else 0xFFFCA5A5.toInt())
        }
        statusTv = st
        box.addView(st, lp(2))

        box.addView(
            if (running) chip("\u25A0  Stop", 0xFFB91C1C.toInt()) { stop() }
            else chip("\u25B6  Start", 0xFF1B8E3E.toInt()) { start() }, lp(10))

        box.addView(
            if (paused) chip("\u25B6  \u0628\u06D5\u0631\u062F\u06D5\u0648\u0627\u0645\u06CC", 0xFF0F766E.toInt()) { resumeAll() }
            else chip("\u23FB  \u0631\u0627\u0648\u0633\u062A\u0627\u0646\u062F\u0646\u0627 \u0647\u06D5\u0645\u06CC\u0627\u0646", 0xFF7F1D1D.toInt()) { pauseAll() }, lp(8))

        val cur = sizeName()
        val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, label) in listOf("small" to "Small", "normal" to "Normal", "big" to "Big")) {
            row.addView(chip(label, if (cur == name) 0xFF7C3AED.toInt() else 0xFF3A3F66.toInt()) { setSize(name) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        }
        box.addView(row, lp(8))
        val au = auto()
        box.addView(chip(if (au) "\u2714 \u062A\u0644\u0642\u0627\u0626\u064A  \u2022  27s" else "\u25CB \u062A\u0644\u0642\u0627\u0626\u064A  \u2022  27s",
            if (au) 0xFF6B7280.toInt() else 0xFF374151.toInt()) { setAuto(!au) }, lp(10))
        if (!au) {
            val cw = word()
            val wrow = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            for (w in listOf("big", "small")) {
                val on = cw == w
                wrow.addView(chip((if (on) "\u2714 " else "") + ar(w), if (on) 0xFF6B7280.toInt() else 0xFF374151.toInt()) { setWord(w) },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
            }
            box.addView(wrow, lp(8))
        }
        box.addView(TextView(svc).apply {
            text = "\u0626\u06D5\u0646\u062C\u0627\u0645\u0627 \u062F\u0648\u0627\u06CC\u06CC \u0628\u0646\u06A4\u06CC\u0633\u06D5:"
            textSize = 12f * sc; setTextColor(0xFFFFE600.toInt())
        }, lp(10))
        val rrow = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
        for (w in listOf("big", "small")) {
            rrow.addView(chip(ar(w), 0xFF0F766E.toInt()) { addResult(w) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(2); rightMargin = dp(2) })
        }
        box.addView(rrow, lp(4))
        box.addView(TextView(svc).apply {
            text = if (hist().isEmpty()) "\u2014" else histView(); textSize = 13f * sc; setTextColor(Color.WHITE)
        }, lp(4))
        streak()?.let { (w, n) ->
            val bigW = hist().count { it == 'B' }; val smallW = hist().length - bigW
            box.addView(TextView(svc).apply {
                text = ar(w) + "  \u00D7" + n + "  \u062F\u06CC\u0641 \u0626\u06CE\u06A9  \u2022  \u0643\u0628\u064A\u0631 " + bigW + " / \u0635\u063A\u064A\u0631 " + smallW
                textSize = 13f * sc; setTextColor(0xFFFFE600.toInt()); setTypeface(typeface, Typeface.BOLD)
            }, lp(4))
            pickByHistory()?.let { opn ->
                box.addView(TextView(svc).apply {
                    text = "\u0628\u06C6\u0686\u0648\u0648\u0646\u0627 \u0626\u06D5\u067E\u06CC:  " + ar(opn)
                    textSize = 15f * sc; setTextColor(if (opn == "big") 0xFF34D399.toInt() else 0xFFFB7185.toInt()); setTypeface(typeface, Typeface.BOLD)
                }, lp(2))
            }
        }
        box.addView(chip("\u21BA", 0xFF374151.toInt()) { clearHist() }, lp(4))
        box.addView(chip("\uD83C\uDFA4", 0xFF1D4ED8.toInt()) { listen() }, lp(8))
        box.addView(chip("\u2715", 0xFF7F1D1D.toInt()) { hideMenu() }, lp(8))

        val b = bubbleLp
        val screenW = svc.resources.displayMetrics.widthPixels
        val mx = if (b == null) dp(24) else if (b.x > screenW / 2) (b.x - dp((232 * sc).toInt())).coerceAtLeast(0) else b.x + dp(60)
        val params = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = mx; y = b?.y ?: dp(200) }
        wm.addView(box, params); menu = box
    }

    // ---------------------------------------------------------------- start / stop
    private fun start() {
        svc.packageManager.getLaunchIntentForPackage(GAME)?.let {
            svc.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        if (paused) { paused = false; prefs.edit().putBoolean("paused", false).apply(); restartCycle() }
        running = true; prefs.edit().putBoolean("running", true).apply(); paint(); rebuildMenu(); pushNow()
    }

    private fun stop() { running = false; prefs.edit().putBoolean("running", false).apply(); paint(); rebuildMenu(); pushNow() }

    // ---------------------------------------------------------------- online (Firebase Realtime Database, REST)
    fun botId(): String {
        val c = Config.BOT_ID.trim()
        if (c.isNotEmpty()) return c
        var id = prefs.getString("bot_id", "") ?: ""
        if (id.isEmpty()) {
            val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
            val r = java.security.SecureRandom()
            id = (1..14).map { chars[r.nextInt(chars.length)] }.joinToString("")
            prefs.edit().putString("bot_id", id).apply()
        }
        return id
    }

    private fun dbReq(method: String, path: String, body: String?): String {
        val c = URL(Config.DB_URL.trimEnd('/') + "/bots/" + botId() + path).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method; c.connectTimeout = 8000; c.readTimeout = 8000
            if (body != null) {
                c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) throw RuntimeException("DB HTTP " + code)
            return txt
        } finally { c.disconnect() }
    }

    private fun statusJson(): String =
        JSONObject().put("running", running).put("size", sizeName()).put("ui", ui()).put("word", word()).put("auto", auto()).put("mood", mood().toDouble()).put("hist", hist()).put("paused", paused)
            .put("ts", JSONObject().put(".sv", "timestamp")).toString()

    private fun showErr() { h.post { statusTv?.text = lineText(); statusTv?.setTextColor(if (err.isEmpty()) 0xFF93C5FD.toInt() else 0xFFFCA5A5.toInt()) } }

    fun pushNow() {
        if (Config.DB_URL.isEmpty()) return
        net.execute { try { dbReq("PUT", "/status.json", statusJson()); err = "" } catch (e: Exception) { err = e.message ?: "error" }; showErr() }
    }

    fun startOnline() {
        if (!paused) ch.postDelayed({ cycle() }, 3000)
        if (Config.DB_URL.isEmpty()) return
        if (hist().isEmpty()) net.execute {   // came back with empty memory: restore history from online
            try {
                val t = dbReq("GET", "/status/hist.json", null).trim().trim('"')
                if (t.matches(Regex("[BS]{1,20}"))) prefs.edit().putString("hist", t).apply()
            } catch (e: Exception) {}
        }
        h.postDelayed({ tick() }, 1000)
    }

    // every 10 seconds: read bots/<id>/cmd  -> apply if it CHANGED, then write bots/<id>/status
    private fun tick() {
        if (!alive) return
        net.execute {
            try {
                val raw = dbReq("GET", "/cmd.json", null).trim()
                if (raw.startsWith("{")) {
                    val cmd = JSONObject(raw)
                    val key = cmd.optString("action") + "|" + cmd.opt("t")
                    val doAction = key != prefs.getString("rlast", "")
                    if (doAction) prefs.edit().putString("rlast", key).apply()
                    h.post { applyCmd(cmd, doAction) }
                }
                dbReq("PUT", "/status.json", statusJson())
                err = ""
            } catch (e: Exception) { err = e.message ?: "error" }
            showErr()
            if (alive) h.postDelayed({ tick() }, 10000)
        }
    }

    private fun applyCmd(c: JSONObject, doAction: Boolean) {
        val want = when (c.optString("size")) {
            "small" -> 70; "big" -> 150; "normal" -> 100
            else -> if (c.has("ui")) c.optInt("ui", 100).coerceIn(60, 220) else ui()
        }
        val changed = want != ui()
        val md = c.optString("mode")
        var wordChanged = false
        if (md == "auto" && !auto()) { prefs.edit().putBoolean("auto", true).apply(); wordChanged = true; restartCycle() }
        else if (md == "manual") {
            val wd = norm(c.optString("word"))
            if (auto() || (wd != null && wd != word())) {
                prefs.edit().putBoolean("auto", false).apply()
                if (wd != null) prefs.edit().putString("word", wd).apply()
                wordChanged = true; restartCycle()
            }
        }
        if (doAction) when (c.optString("action")) {
            "start" -> start()
            "stop" -> stop()
            "menu" -> openMenu()
            "hide_menu" -> hideMenu()
        }
        if (changed) rebuildMenu()
        if (changed || doAction || wordChanged) pushNow()
    }

    fun destroy() {
        try { sr?.destroy() } catch (e: Exception) {}
        alive = false; h.removeCallbacksAndMessages(null); ch.removeCallbacksAndMessages(null)
        hideMenu()
        badgeTv?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble = null
    }
}
